package com.dilermando.reddit.presentation

interface BaseView {

}
